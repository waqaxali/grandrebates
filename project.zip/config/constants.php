<?php

return [
    'app_name'=>'Grandrebates',
    'per_page'=>'2',
];

?>
