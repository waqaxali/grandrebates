<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
class SocialShareButtonsController extends Controller
{
    public function ShareWidget()
    {
        $username = explode('@', Auth::user()->email);


        $shareComponent = \Share::page(

            "<a href='http://127.0.0.1:8000/reffereduser/'></a>",
            'Your share text comes here',
        )
        ->facebook()
        ->twitter()
        ->linkedin()
        ->telegram()
        ->whatsapp();


        return view('share', compact('shareComponent'));
    }
    public function reffered_users($username)
    {
      dd($username);
    }
}
