<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\store;
use App\Models\Country;
use App\Models\Category;
use App\Models\Network;
use App\Models\User;
use Auth;
use Alert;

class storecontroller extends Controller
{
     function __construct(){
                $this->store= new store;
                $this->country= new Country;
                $this->network = new Network;
                $this->category= new Category;
            }

    public function all_store(){
                $all_store=$this->store::with('networks','categories')->where('is_active',1)->orderBy('id','DESC')->get();
            //dd($all_store);
                return view('adminpanel.all_store',compact('all_store'));
            }
    public function add_store(Request $request){
                    $all_category=$this->category::where('category_type','store')->get();
                    $all_country=$this->country::all();
                    $all_network=$this->network::all();

                return view('adminpanel.add_store',compact('all_network','all_country','all_category'));
            }

    public function save_store(Request $request){
        $request->validate([

             'store_name'=>'required',

       ]);

                    $this->store->user_id=Auth::user()->id;

                    $this->store->store_name=$request->store_name;
                    $this->store->slug=phpslug($request->store_name);
                    $this->store->use_network=$request->use_network;
                    $this->store->use_skimlinks=$request->use_skimlinks;
                    $this->store->use_viglink=$request->use_viglink;
                    $this->store->cashback_commission=$request->cashback_commission;
                    $this->store->network_cashback=$request->network_cashback;
                    $this->store->network_commission=$request->network_commission;
                    $this->store->network_flat_switch=$request->network_flat_switch;
                    $this->store->network_flat_rate=$request->network_flat_rate;
                    $this->store->skimlinks_min=$request->skimlinks_min;
                    $this->store->skimlinks_flat_rate=$request->skimlinks_flat_rate;

                    $this->store->status=$request->status;
                    $this->store->homepage_url=$request->homepage_url;
                    $this->store->affliated_url=$request->affliated_url;
                    $this->store->show_store_description=$request->show_store_description;
                    $this->store->store_main_description=$request->store_main_description;
                    $this->store->description_about_section=$request->description_about_section;

                    $this->store->custom_cashback_title=$request->custom_cashback_title;
                    $this->store->custom_cashback_subtitle=$request->custom_cashback_subtitle;
                    $this->store->custom_commission_title=$request->custom_commission_title;
                    $this->store->custom_commission_subtitle=$request->custom_commission_subtitle;
                    $this->store->show_serp=$request->show_serp;
                    $this->store->scrap_promocodes=$request->scrap_promocodes;
                    $this->store->show_amazon=$request->show_amazon;
                    $this->store->country_id=$request->country_id;
                    $this->store->category_id=$request->category_id;
                    $this->store->network_id=$request->network_id;

                    $this->store->instagram_url=$request->instagram_url;
                    $this->store->pinterest_url=$request->pinterest_url;
                    $this->store->youtube_url=$request->youtube_url;
                    $this->store->facebook_url=$request->facebook_url;
                    $this->store->twitter_url=$request->twitter_url;

                    //when migration refresh again remove this
                    $this->store->is_active='1';

                    $this->store->custom_h1=$request->custom_h1;
                    $this->store->slug_suffix=$request->slug_suffix;
                    $this->store->referral_slug=$request->referral_slug;
                    $this->store->custom_meta_title=$request->custom_meta_title;
                    $this->store->custom_meta_description=$request->custom_meta_description;
                    if($request->file('logo')){
                        $file= $request->file('logo');
                        $filename= date('YmdHi').uniqid().$file->getClientOriginalName();
                        $file-> move(public_path('images'), $filename);
                        $this->store->logo= $filename;
                    }
                    if($request->file('featured_image')){
                        $file= $request->file('featured_image');
                        $filename= date('YmdHi').uniqid().$file->getClientOriginalName();
                        $file-> move(public_path('images'), $filename);
                        $this->store->featured_image= $filename;
                    }
                    //($request);
                  $success= $this->store->save();

                   if($success==true){
                    toast('Successfully save!','success')->timerProgressBar()->width('400px');

                        return redirect()->route('all_store');
                    }else{
                        toast('Something went wrong!','error')->timerProgressBar()->width('400px');
                        return redirect()->route('add_store');
                    }

            }
    public function edit_store(Request $request,$id){
                $all_category=$this->category::where('category_type','store')->get();
                $all_country=$this->country::all();
                $all_network=$this->network::all();
                $current_store = $this->store::find($id);
                return view('adminpanel.edit_store',compact('current_store','all_network','all_country','all_category'));
            }

    public function update_store(Request $request,$id){

//dd($request);
                    $update= $this->store->find($id);
                    $update->store_name=$request->store_name;
                    $update->slug=phpslug($request->store_name);
                    $update->use_network=$request->use_network;
                    $update->use_skimlinks=$request->use_skimlinks;
                    $update->use_viglink=$request->use_viglink;
                    $update->cashback_commission=$request->cashback_commission;
                    $update->network_cashback=$request->network_cashback;
                    $update->network_commission=$request->network_commission;
                    $update->network_flat_switch=$request->network_flat_switch;
                    $update->network_flat_rate=$request->network_flat_rate;
                    $update->skimlinks_min=$request->skimlinks_min;
                    $update->skimlinks_flat_rate=$request->skimlinks_flat_rate;
                    $update->network_id=$request->network_id;
                    $update->status=$request->status;
                    $update->homepage_url=$request->homepage_url;
                    $update->affliated_url=$request->affliated_url;
                    $update->show_store_description=$request->show_store_description;
                    $update->store_main_description=$request->store_main_description;
                    $update->description_about_section=$request->description_about_section;

                    $update->custom_cashback_title=$request->custom_cashback_title;
                    $update->custom_cashback_subtitle=$request->custom_cashback_subtitle;
                    $update->custom_commission_title=$request->custom_commission_title;
                    $update->custom_commission_subtitle=$request->custom_commission_subtitle;

                    $update->show_serp=$request->show_serp;
                    $update->scrap_promocodes=$request->scrap_promocodes;
                    $update->show_amazon=$request->show_amazon;
                    $update->country_id=$request->country_id;
                    $update->category_id=$request->category_id;

                    $update->instagram_url=$request->instagram_url;
                    $update->pinterest_url=$request->pinterest_url;
                    $update->youtube_url=$request->youtube_url;
                    $update->facebook_url=$request->facebook_url;
                    $update->twitter_url=$request->twitter_url;

                    $update->custom_h1=$request->custom_h1;
                    $update->slug_suffix=$request->slug_suffix;
                    $update->referral_slug=$request->referral_slug;
                    $update->custom_meta_title=$request->custom_meta_title;
                    $update->custom_meta_description=$request->custom_meta_description;
                    if($request->file('logo')){
                        $file= $request->file('logo');
                        $filename= date('YmdHi').uniqid().$file->getClientOriginalName();
                        $file-> move(public_path('images'), $filename);
                        $update->logo= $filename;
                    }
                    if($request->file('featured_image')){
                        $file= $request->file('featured_image');
                        $filename= date('YmdHi').uniqid().$file->getClientOriginalName();
                        $file-> move(public_path('images'), $filename);
                        $update->featured_image= $filename;
                    }
                   // dd($request);
                $success= $update->update();
                if($success==true){
                    toast('Successfully update record!','success')->timerProgressBar()->width('400px');
                    return redirect()->route('all_store');
                }
                else{
                    toast('Oops Something went wrong!','error')->timerProgressBar()->width('400px');
                    return redirect()->route('edit_store');
                }
    }
    public function delete_store($id){
        $success= $this->store::where('id',$id)->update([
            'is_active' => 2,
        ]);
        if($success==true){
            toast('Successfully update record!','success')->timerProgressBar()->width('400px');
            return redirect()->route('all_store');
        }
    }


    public function stores(){
        $all_category=$this->category::where('category_type','store')->where('is_active',1)->orderBy('id','DESC')->get();
        $all_store=$this->store::with('networks','categories')->where('is_active',1)->orderBy('id','DESC')->paginate(25);
        return view('adminpanel.user.stores',compact('all_store','all_category'));
    }
}
