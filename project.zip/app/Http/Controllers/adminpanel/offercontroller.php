<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Offer;
use App\Models\store;
use Auth;
use Alert;
class offercontroller extends Controller
{
    function __construct(){

        $this->offer= new Offer;
        $this->store= new store;

    }
    public function all_offers(){
         $all_offers=$this->offer::with('stores')->where('is_active','1')->get();

        return view('adminpanel.offers.all_offers',compact('all_offers'));
    }

    public function add_offer(){
            $all_store=$this->store::orderBy('id','desc')->where('is_active','1')->get();
            return view('adminpanel.offers.add_offers',compact('all_store'));
        }
    public function save_offer(Request $request){
        $this->offer->store_id=$request->store_id;
        $this->offer->kind=$request->kind;
        $this->offer->short_title=$request->short_title;
        $this->offer->title=$request->title;
        $this->offer->description=$request->description;
        $this->offer->imported_desciption=$request->imported_desciption;
        $this->offer->code=$request->code;
        $this->offer->end_date=$request->end_date;
        $this->offer->user_id=Auth::user()->id;
        $success=$this->offer->save();
        if($success==true){
            toast('Successfully save!','success')->timerProgressBar()->width('400px');

                return redirect()->route('all_offers');
            }else{
                toast('Something went wrong!','error')->timerProgressBar()->width('400px');
                return redirect()->route('add_offer');
            }

        }
    public function edit_offer(Request $request,$id){
             $all_store=$this->store::orderBy('id','desc')->get();
            $current_offer = $this->offer::find($id);
            return view('adminpanel.offers.edit_offers',compact('current_offer','all_store'));
        }

     public function update_offer(Request $request,$id){
        $update=$this->offer->find($id);
            $update->store_id=$request->store_id;
            $update->kind=$request->kind;
            $update->short_title=$request->short_title;
            $update->title=$request->title;
            $update->description=$request->description;
            $update->imported_desciption=$request->imported_desciption;
            $update->code=$request->code;
            $update->end_date=$request->end_date;
            $update->user_id=Auth::user()->id;
            $success=$update->update();
            if($success==true){
                toast('Successfully update!','success')->timerProgressBar()->width('400px');

                    return redirect()->route('all_offers');
                }else{
                    toast('Something went wrong!','error')->timerProgressBar()->width('400px');
                    return redirect()->route('add_offer');
                }

            }
    public function delete_offer(Request $request,$id){
                    $update=$this->offer->find($id);
                    $update->is_active='2';
                    $success=$update->update();
                    if($success==true){
                        toast('Successfully deleted record!','success')->timerProgressBar()->width('400px');

                            return redirect()->route('all_offers');
                        }

                }
}
