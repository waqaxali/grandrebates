<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Feature extends Model
{
    use HasFactory;

    public function categories()
    {
        return $this->belongsTo(Category::class,'featureable_item_id','id');
    }

    public function stores()
    {
        return $this->belongsTo(store::class,'featureable_item_id','id');
    }
    // public function features()
    // {
    //     return $this->belongsTo(Feature::class,'featureable_item_id','id');
    // }
}
