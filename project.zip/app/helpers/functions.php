<?php

if(!function_exists('phpslug')){
    function phpslug($string)
    {
        $slug = preg_replace('/[-\s]+/', '-', strtolower(trim($string)));
        return $slug;
    }
}
if(!function_exists('p')){
    function p($data){
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    }
}



?>
